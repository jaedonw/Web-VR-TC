export const environment = {
  production: false,
  apiEndpoint: 'http://localhost:3000',
};
