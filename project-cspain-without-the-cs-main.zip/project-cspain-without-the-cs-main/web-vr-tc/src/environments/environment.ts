export const environment = {
  production: true,
  apiEndpoint: 'https://api.webvrtc.me',
};
