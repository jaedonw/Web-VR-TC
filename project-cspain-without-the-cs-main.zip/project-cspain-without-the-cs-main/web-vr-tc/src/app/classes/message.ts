export class Message {
  sender: string;
  content: string;
}
