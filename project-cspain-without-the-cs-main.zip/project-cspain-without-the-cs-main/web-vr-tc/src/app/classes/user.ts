export interface User {
  id: string;
  username: string;
  premiumEnabled: boolean;
}
